<?php
    header("Access-Control-Allow-Origin: *");
    ini_set('display_errors', true);
    error_reporting(E_ALL);

    include_once("con.php");
    $pdo = conectar();

    $getChiefsMenu=$pdo->prepare("SELECT * FROM chiefs");
    $getChiefsMenu->execute();

    while ($line=$getChiefsMenu->fetch(PDO::FETCH_ASSOC)) {
        $name = $line['name'];
        $meni = $line['meni'];
        $price = $line['price'];

        $return[] = array(
            'name' => $name,
            'meni' => $meni,
            'price' => $price
        );
    }

    echo json_encode($return);
?>